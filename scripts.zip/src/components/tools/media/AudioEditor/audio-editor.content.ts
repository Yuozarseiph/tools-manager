// app/tools/(audio)/audio-editor/audio-editor.content.ts

import { useLanguage } from "@/context/LanguageContext";

export const audioEditorContent = {
  fa: {
    id: "audio-editor",
    category: "audio",
    title: "ویرایش و پردازش صدا (بتا)",
    description: "فایل صوتی خود را به صورت محلی در مرورگر برش دهید، افکت Fade اعمال کنید یا بلندی صدا را تنظیم و نرمال‌سازی کنید؛ بدون آپلود روی سرور.",
    features: [
      "برش بخش دلخواه از صدا و خروجی WAV",
      "افکت Fade In / Fade Out روی بازه انتخابی",
      "تنظیم بلندی صدا بر حسب دسی‌بل",
      "نرمال‌سازی خودکار صدا بدون کلیپ",
      "پردازش ۱۰۰٪ روی دستگاه شما (Client-side)"
    ],
    ui: {
      tabs: {
        trim: "برش صدا (بتا)",
        volume: "تنظیم بلندی / نرمال‌سازی",
        equalizer: "اکولایزر (۳۱ باند)",
        waveform: "موج صدا / تایم‌لاین"
      },
      header: {
        smallTitle: "ابزارهای صوتی",
        subtitle: "همه پردازش‌ها فقط روی دستگاه شما انجام می‌شود."
      },
      trim: {
        upload: {
          title: "انتخاب فایل صوتی",
          description: "فرمت‌های رایج مانند MP3، WAV و OGG پشتیبانی می‌شوند. فایل فقط روی دستگاه شما پردازش می‌شود.",
          button: "انتخاب فایل"
        },
        fileInfo: {
          totalDurationLabel: "مدت کل:",
          currentPositionLabel: "موقعیت فعلی:",
          selectionLabel: "بازه انتخابی:",
          noFileTitle: "هنوز فایلی انتخاب نشده است",
          noFileDescription: "یک فایل صوتی انتخاب کنید تا بتوانید آن را پخش، برش و با افکت‌های ساده خروجی WAV دریافت کنید."
        },
        transport: {
          playAll: "پخش کل فایل",
          stop: "توقف",
          playHelper: "برای گوش‌دادن به کل فایل از این دکمه استفاده کنید."
        },
        selection: {
          title: "محدوده برش",
          resetLabel: "ریست بازه",
          startLabel: "شروع (ثانیه)",
          endLabel: "پایان (ثانیه)",
          playSelectionPrefix: "پخش بازه انتخاب‌شده",
          downloadIdle: "دانلود بخش انتخاب‌شده",
          downloadWorking: "در حال ساخت فایل..."
        },
        fade: {
          title: "افکت‌های نرم‌کننده صدا",
          description: "قبل از دانلود، می‌توانید شروع و پایان صدا را نرم‌تر کنید (Fade In / Fade Out).",
          fadeInLabel: "فعال‌سازی Fade In",
          fadeOutLabel: "فعال‌سازی Fade Out",
          fadeInDurationLabel: "مدت Fade In (ثانیه)",
          fadeOutDurationLabel: "مدت Fade Out (ثانیه)"
        },
        errors: {
          decode: "خطا در پردازش فایل صوتی.",
          export: "خطا در ساخت فایل خروجی."
        },
        empty: {
          title: "هنوز فایلی انتخاب نشده است",
          description: "یک فایل صوتی انتخاب کنید تا بتوانید آن را پخش، برش دهید و با افکت‌های ساده خروجی WAV دریافت کنید."
        }
      },
      volume: {
        upload: {
          title: "انتخاب فایل صوتی",
          description: "فایل صوتی خود را آپلود کنید تا بلندی صدا را تنظیم یا آن را نرمال‌سازی کنید. پردازش فقط روی مرورگر شما انجام می‌شود.",
          button: "انتخاب فایل"
        },
        fileInfo: {
          durationLabel: "مدت:",
          currentPositionLabel: "موقعیت فعلی:",
          noFileTitle: "هنوز فایلی انتخاب نشده است",
          noFileDescription: "یک فایل صوتی انتخاب کنید تا بتوانید بلندی آن را تنظیم یا آن را نرمال‌سازی کنید و خروجی WAV بگیرید."
        },
        transport: {
          play: "پخش فایل",
          stop: "توقف",
          helper: "این پخش فقط نسخه اصلی فایل را نشان می‌دهد؛ تنظیمات روی نسخه خروجی اعمال می‌شوند."
        },
        controls: {
          title: "تنظیم بلندی صدا",
          description: "می‌توانید سطح صدا را بر حسب دسی‌بل تغییر دهید یا آن را به صورت خودکار نرمال‌سازی کنید تا پیک صدا نزدیک حداکثر شود بدون این‌که کلیپ شود.",
          gainLabel: "سطح صدا (دسی‌بل)",
          normalizeLabel: "نرمال‌سازی خودکار به حداکثر بلندی بدون کلیپ"
        },
        actions: {
          downloadIdle: "دانلود نسخه تنظیم‌شده",
          downloadWorking: "در حال ساخت فایل..."
        },
        errors: {
          decode: "خطا در پردازش فایل صوتی.",
          export: "خطا در ساخت فایل خروجی."
        },
        empty: {
          title: "هنوز فایلی انتخاب نشده است",
          description: "یک فایل صوتی انتخاب کنید تا بتوانید بلندی آن را تنظیم یا آن را نرمال‌سازی کنید و خروجی WAV بگیرید."
        }
      },
      equalizer: {
        upload: {
          title: "انتخاب فایل صوتی",
          description: "فایل صوتی را انتخاب کنید تا اکولایزر ۳۱ باند را روی آن اعمال کنید. پردازش فقط روی مرورگر شما انجام می‌شود.",
          button: "انتخاب فایل"
        },
        fileInfo: {
          durationLabel: "مدت:",
          currentPositionLabel: "موقعیت فعلی:",
          noFileTitle: "هنوز فایلی انتخاب نشده است",
          noFileDescription: "یک فایل صوتی انتخاب کنید تا بتوانید اکولایزر را اعمال کنید و خروجی WAV بگیرید."
        },
        transport: {
          play: "پخش",
          pause: "توقف"
        },
        controls: {
          title: "اکولایزر ۳۱ باند",
          subtitle: "ستون‌ها را بالا/پایین بکشید. خط وسط 0dB است.",
          resetLabel: "ریست اکولایزر",
          rangeLabel: "بازه: -12dB تا +12dB",
          tip: "نکته: با کلیک روی ستون هم مقدار سریع تنظیم می‌شود."
        },
        actions: {
          downloadIdle: "دانلود خروجی WAV",
          downloadWorking: "در حال ساخت فایل..."
        },
        errors: {
          decode: "خطا در پردازش فایل صوتی.",
          export: "خطا در ساخت فایل خروجی."
        },
        empty: {
          title: "هنوز فایلی انتخاب نشده است",
          description: "برای شروع، یک فایل صوتی انتخاب کنید."
        }
      },
      waveform: {
        title: "موج صدا / تایم‌لاین"
      },
      page: {
        title: "ویرایش و پردازش صدا (بتا)",
        description: "فایل صوتی خود را انتخاب کنید و به صورت محلی روی دستگاه خود آن را برش دهید، تنظیم کنید یا برای پردازش‌های بعدی آماده کنید. هیچ فایلی آپلود نمی‌شود و همه‌چیز فقط در مرورگر شما انجام می‌شود."
      }
    }
  },
  en: {
    id: "audio-editor",
    title: "Audio editing (beta)",
    category: "audio",
    description: "Cut, fade and normalize audio files directly in your browser, with all processing done locally on your device.",
    features: [
      "Trim any part of the audio and export as WAV",
      "Apply fade-in and fade-out on the selected range",
      "Adjust volume in decibels (dB)",
      "Automatically normalize audio without clipping",
      "100% client-side processing for privacy"
    ],
    ui: {
      tabs: {
        trim: "Trim audio (beta)",
        volume: "Volume / normalization",
        equalizer: "Equalizer (31-band)",
        waveform: "Waveform / timeline"
      },
      header: {
        smallTitle: "Audio tools",
        subtitle: "All processing happens locally in your browser."
      },
      trim: {
        upload: {
          title: "Select audio file",
          description: "Common formats like MP3, WAV and OGG are supported. The file is processed only on your device.",
          button: "Choose file"
        },
        fileInfo: {
          totalDurationLabel: "Total duration:",
          currentPositionLabel: "Current position:",
          selectionLabel: "Selected range:",
          noFileTitle: "No file selected yet",
          noFileDescription: "Choose an audio file to play it, trim a range and export a WAV file with simple fade effects."
        },
        transport: {
          playAll: "Play full file",
          stop: "Stop",
          playHelper: "Use this button to listen to the entire file."
        },
        selection: {
          title: "Trim range",
          resetLabel: "Reset range",
          startLabel: "Start (seconds)",
          endLabel: "End (seconds)",
          playSelectionPrefix: "Play selected range",
          downloadIdle: "Download selected part",
          downloadWorking: "Generating file..."
        },
        fade: {
          title: "Smooth fade effects",
          description: "Before downloading you can smooth the start and end of the audio with fade-in and fade-out.",
          fadeInLabel: "Enable Fade In",
          fadeOutLabel: "Enable Fade Out",
          fadeInDurationLabel: "Fade In duration (seconds)",
          fadeOutDurationLabel: "Fade Out duration (seconds)"
        },
        errors: {
          decode: "Error while processing the audio file.",
          export: "Error while generating the output file."
        },
        empty: {
          title: "No file selected yet",
          description: "Choose an audio file to play, trim it and export the selected part as a WAV file."
        }
      },
      volume: {
        upload: {
          title: "Select audio file",
          description: "Upload an audio file to adjust its loudness or normalize it. Processing is done entirely in your browser.",
          button: "Choose file"
        },
        fileInfo: {
          durationLabel: "Duration:",
          currentPositionLabel: "Current position:",
          noFileTitle: "No file selected yet",
          noFileDescription: "Choose an audio file to change its volume or normalize it and then export a WAV file."
        },
        transport: {
          play: "Play file",
          stop: "Stop",
          helper: "Playback uses the original file only; your adjustments apply to the exported version."
        },
        controls: {
          title: "Volume control",
          description: "Change the volume in decibels or let the tool normalize the audio so peaks are close to maximum without clipping.",
          gainLabel: "Volume level (dB)",
          normalizeLabel: "Auto-normalize to maximum loudness without clipping"
        },
        actions: {
          downloadIdle: "Download processed version",
          downloadWorking: "Generating file..."
        },
        errors: {
          decode: "Error while processing the audio file.",
          export: "Error while generating the output file."
        },
        empty: {
          title: "No file selected yet",
          description: "Choose an audio file to adjust its loudness or normalize it and export a WAV file."
        }
      },
      equalizer: {
        upload: {
          title: "Select audio file",
          description: "Choose an audio file to apply a 31-band EQ. Processing is done entirely in your browser.",
          button: "Choose file"
        },
        fileInfo: {
          durationLabel: "Duration:",
          currentPositionLabel: "Current position:",
          noFileTitle: "No file selected yet",
          noFileDescription: "Choose an audio file to apply EQ and export a WAV file."
        },
        transport: {
          play: "Play",
          pause: "Pause"
        },
        controls: {
          title: "31-band Equalizer",
          subtitle: "Drag columns up/down. The middle line is 0dB.",
          resetLabel: "Reset EQ",
          rangeLabel: "Range: -12dB to +12dB",
          tip: "Tip: Clicking a column also sets the value quickly."
        },
        actions: {
          downloadIdle: "Download WAV output",
          downloadWorking: "Generating file..."
        },
        errors: {
          decode: "Error while processing the audio file.",
          export: "Error while generating the output file."
        },
        empty: {
          title: "No file selected yet",
          description: "Choose an audio file to get started."
        }
      },
      waveform: {
        title: "Waveform / timeline"
      },
      page: {
        title: "Audio editing (beta)",
        description: "Select an audio file and trim it, apply fades or adjust volume entirely on your device. Nothing is uploaded to a server."
      }
    }
  }
};

export type AudioEditorToolContent = typeof audioEditorContent.fa;

export function useAudioEditorContent() {
  const { locale } = useLanguage();
  return audioEditorContent[locale];
}
