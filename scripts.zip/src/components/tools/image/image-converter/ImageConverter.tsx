// components/tools/developer/image-converter/ImageConverter.tsx
"use client";
import { outputFilename } from "@/lib/output-name";
import { AccessibleDropzone } from "@/components/ui/AccessibleControls";
import { AccessibleButton } from "@/components/ui/AccessibleControls";
import { AccessibleInput } from "@/components/ui/AccessibleControls";

import { useState, useEffect, useRef, type ChangeEvent } from "react";
import { useDropzone } from "react-dropzone";
import { saveFile as download } from "@/lib/file-export";
import JSZip from "jszip";
import {
  FileUp,
  Trash2,
  Image as ImageIcon,
  Loader2,
  Download,
  ArrowLeftRight,
  X,
  FolderArchive,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// مطمئن شوید فایل image-actions.ts را در مسیر utils ساخته‌اید
import { convertImages, ImageFormat } from "@/utils/image-actions";
import { useThemeColors } from "@/hooks/useThemeColors";
import {
  useImageConverterContent,
  type ImageConverterToolContent,
} from "./image-converter.content"; //  مسیر اصلاح شده

interface FileWithPreview extends File {
  preview: string;
  id: string;
}

export default function ImageConverter() {
  const theme = useThemeColors();
  const content: ImageConverterToolContent = useImageConverterContent();

  const [files, setFiles] = useState<FileWithPreview[]>([]);
  const previewUrls = useRef(new Set<string>());
  const [targetFormat, setTargetFormat] = useState<ImageFormat>("image/jpeg");
  const [quality, setQuality] = useState(90);
  const [isProcessing, setIsProcessing] = useState(false);

  // برای لود از URL
  const [imageUrlInput, setImageUrlInput] = useState("");
  const [isAddingFromUrl, setIsAddingFromUrl] = useState(false);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      "image/*": [
        ".png",
        ".jpg",
        ".jpeg",
        ".webp",
        ".gif",
        ".bmp",
        ".tiff",
        ".svg",
        ".avif",
      ],
    },
    maxFiles: 20,
    onDrop: (acceptedFiles) => {
      const room = Math.max(0, 20 - files.length);
      const added = acceptedFiles.slice(0, room).map((file) => {
        const preview = URL.createObjectURL(file);
        previewUrls.current.add(preview);
        return Object.assign(file, {
          preview,
          id: `${file.name}-${Date.now()}-${Math.random()}`,
        });
      });
      setFiles((prev) => [...prev, ...added]);
    },
  });

  useEffect(() => {
    return () => {
      previewUrls.current.forEach((url) => URL.revokeObjectURL(url));
      previewUrls.current.clear();
    };
  }, []);

  const handleConvert = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);

    try {
      const results = await convertImages(files, targetFormat, {
        quality: quality / 100,
      });

      if (results.length === 1) {
        download(results[0].converted, outputFilename(results[0].filename), results[0].converted.type);
      } else {
        const zip = new JSZip();
        results.forEach((result, index) => {
          zip.file(outputFilename(result.filename, String(index + 1)), result.converted);
        });

        const zipBlob = await zip.generateAsync({ type: "blob" });
        download(zipBlob, outputFilename("converted-images.zip"), "application/zip");
      }
    } catch (err) {
      alert(content.ui.alerts.error);
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const removeFile = (id: string) => {
    const file = files.find((f) => f.id === id);
    if (file) {
      previewUrls.current.delete(file.preview);
      URL.revokeObjectURL(file.preview);
    }
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const clearAllFiles = () => {
    files.forEach((file) => { previewUrls.current.delete(file.preview); URL.revokeObjectURL(file.preview); });
    setFiles([]);
  };

  // افزودن تصویر از URL (با اینترنت کاربر دانلود می‌شود)
  const handleAddFromUrl = async () => {
    const url = imageUrlInput.trim();
    if (!url) return;
    if (files.length >= 20) return;

    setIsAddingFromUrl(true);
    try {
      const res = await fetch(url, { mode: "cors" });
      if (!res.ok) {
        throw new Error("Failed to fetch image");
      }

      const blob = await res.blob();
      if (!blob.type.startsWith("image/")) {
        throw new Error("Not an image");
      }

      const urlParts = url.split("/");
      const lastPart = urlParts[urlParts.length - 1] || "image-from-url";
      const cleanName = lastPart.split("?")[0] || "image-from-url";

      const file = new File([blob], cleanName, {
        type: blob.type || "image/*",
      });

      const fileWithPreview: FileWithPreview = Object.assign(file, {
        preview: URL.createObjectURL(file),
        id: `${cleanName}-${Date.now()}-${Math.random()}`,
      });

      previewUrls.current.add(fileWithPreview.preview);
      setFiles((prev) => [...prev, fileWithPreview]);
      setImageUrlInput("");
    } catch (err) {
      alert(content.ui.alerts.error);
      console.error(err);
    } finally {
      setIsAddingFromUrl(false);
    }
  };

  const formats = [
    {
      value: "image/jpeg",
      label: "JPG",
      desc: content.ui.formats.jpegDesc,
    },
    {
      value: "image/png",
      label: "PNG",
      desc: content.ui.formats.pngDesc,
    },
    {
      value: "image/webp",
      label: "WebP",
      desc: content.ui.formats.webpDesc,
    },
    {
      value: "image/avif",
      label: "AVIF",
      desc: content.ui.formats.avifDesc,
    },
    {
      value: "image/gif",
      label: "GIF",
      desc: content.ui.formats.gifDesc,
    },
    {
      value: "image/bmp",
      label: "BMP",
      desc: content.ui.formats.bmpDesc,
    },
  ] as const;

  return (
    <div
      className={`rounded-3xl border p-6 md:p-10 shadow-xl transition-colors duration-300 ${theme.card} ${theme.border}`}
    >
      {/* آپلودر (دیوایس / درگ‌درآپ) */}
      {files.length === 0 ? (
        <AccessibleDropzone
          {...getRootProps()}
          className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-200
          ${
            isDragActive
              ? "border-[var(--app-accent)] scale-[0.99]"
              : `${theme.border} hover:border-[var(--app-accent)]`
          }
          ${theme.bg}`}
        >
          <AccessibleInput {...getInputProps()} />
          <div className="flex flex-col items-center gap-4">
            <div className={`p-4 rounded-full ${theme.secondary}`}>
              <FileUp size={32} className={theme.accent} />
            </div>
            <p className={`text-lg font-bold ${theme.text}`}>
              {content.ui.upload.dropTitle}
            </p>
            <p className={`text-sm ${theme.textMuted}`}>
              {content.ui.upload.dropSubtitle}
            </p>
          </div>
        </AccessibleDropzone>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-6"
        >
          {/* گالری پیش‌نمایش */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-h-96 overflow-y-auto p-2">
            <AnimatePresence mode="popLayout">
              {files.map((file) => (
                <motion.div
                  key={file.id}
                  layout
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{
                    opacity: 0,
                    scale: 0.8,
                    transition: { duration: 0.2 },
                  }}
                  className={`relative group rounded-xl overflow-hidden border-2 ${theme.border} ${theme.bg} shadow-md hover:shadow-lg transition-all`}
                >
                  <div className="aspect-square relative bg-gray-100">
                    <img
                      src={file.preview}
                      alt={file.name}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />

                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <AccessibleButton purpose="delete"
                        onClick={() => removeFile(file.id)}
                        className="p-3 bg-red-500 hover:bg-red-600 text-white rounded-full transition-transform hover:scale-110"
                        type="button"
                      >
                        <Trash2 size={20} />
                      </AccessibleButton>
                    </div>
                  </div>

                  <div className="p-2">
                    <p className={`text-xs font-medium truncate ${theme.text}`}>
                      {file.name}
                    </p>
                    <p className={`text-xs ${theme.textMuted}`}>
                      {(file.size / 1024).toFixed(0)}{" "}
                      {content.ui.gallery.sizeUnit}
                    </p>
                  </div>

                  <AccessibleButton purpose="close"
                    onClick={() => removeFile(file.id)}
                    className="absolute top-2 left-2 p-1.5 bg-red-500 text-white rounded-full shadow-lg md:hidden"
                    type="button"
                  >
                    <X size={14} />
                  </AccessibleButton>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* دکمه افزودن بیشتر (از دیوایس) */}
          <button
            {...getRootProps()}
            type="button"
            className={`w-full py-3 rounded-xl border-2 border-dashed font-medium transition ${theme.border} ${theme.text} hover:border-[var(--app-accent)]`}
          >
            <AccessibleInput {...getInputProps()} />
            {content.ui.upload.addMore} ({files.length}/20{" "}
            {content.ui.upload.counterSuffix})
          </button>

          {/* تنظیمات فرمت */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 justify-center">
              <span className={`text-sm ${theme.textMuted}`}>
                {content.ui.formats.title}
              </span>
              <ArrowLeftRight size={16} className={theme.textMuted} />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {formats.map((fmt) => (
                <button
                  key={fmt.value}
                  type="button"
                  onClick={() => setTargetFormat(fmt.value as ImageFormat)}
                  className={`p-3 rounded-xl text-sm font-medium transition-all border text-center
                    ${
                      targetFormat === fmt.value
                        ? `${theme.primary} border-transparent shadow-lg`
                        : `${theme.bg} ${theme.border} ${theme.text} hover:brightness-95`
                    }`}
                >
                  <div className="font-bold">{fmt.label}</div>
                  <div className="text-xs opacity-100 mt-1">{fmt.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* کیفیت */}
          {["image/jpeg", "image/webp", "image/avif"].includes(
            targetFormat
          ) && (
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className={`text-sm font-medium ${theme.text}`}>
                  {content.ui.quality.label}
                </label>
                <span className={`text-sm font-bold ${theme.accent}`}>
                  {quality}%
                </span>
              </div>
              <AccessibleInput
                type="range"
                min="10"
                max="100"
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full accent-[var(--app-accent)]"
              />
              <div className="flex justify-between text-xs text-[var(--app-text-muted)]">
                <span>{content.ui.quality.low}</span>
                <span>{content.ui.quality.high}</span>
              </div>
            </div>
          )}

          {/* دکمه‌های اکشن */}
          <div className="space-y-3">
            <button data-testid="download-result"
              onClick={handleConvert}
              disabled={isProcessing}
              type="button"
              className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-lg active:scale-[0.98] ${theme.primary} disabled:opacity-50`}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="animate-spin" />{" "}
                  {content.ui.buttons.processing}
                </>
              ) : files.length > 1 ? (
                <>
                  <FolderArchive /> {content.ui.buttons.convertMulti} (
                  {files.length})
                </>
              ) : (
                <>
                  <Download /> {content.ui.buttons.convertSingle}
                </>
              )}
            </button>

            <button
              onClick={clearAllFiles}
              type="button"
              className={`w-full py-2 rounded-xl text-sm font-medium transition ${theme.textMuted} hover:text-red-500`}
            >
              <Trash2 size={16} className="inline ml-2" />
              {content.ui.buttons.clearAll}
            </button>
          </div>
        </motion.div>
      )}

      {/* لود از URL (پایین کارت، همیشه در دسترس) */}
      <div className="mt-6 space-y-2">
        <p className={`text-xs ${theme.textMuted}`}>
          {content.ui.upload.urlHint}
        </p>
        <div className="flex flex-col sm:flex-row gap-2">
          <AccessibleInput
            type="url"
            value={imageUrlInput}
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setImageUrlInput(e.target.value)
            }
            placeholder={content.ui.upload.urlPlaceholder}
            className={`flex-1 px-3 py-2 rounded-xl text-xs border ${theme.border} ${theme.bg} ${theme.text} focus:outline-none focus:ring-1 focus:ring-[var(--app-accent)]`}
          />
          <button
            type="button"
            onClick={handleAddFromUrl}
            disabled={isAddingFromUrl}
            className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-800 text-slate-100 hover:bg-slate-700 disabled:opacity-60"
          >
            {isAddingFromUrl
              ? content.ui.upload.urlLoading
              : content.ui.upload.urlButton}
          </button>
        </div>
      </div>
    </div>
  );
}
