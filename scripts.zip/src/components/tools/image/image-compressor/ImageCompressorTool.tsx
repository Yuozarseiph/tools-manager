// components/tools/developer/image-compressor/ImageCompressorTool.tsx
"use client";
import { outputFilename } from "@/lib/output-name";
import { AccessibleDropzone } from "@/components/ui/AccessibleControls";
import { AccessibleButton } from "@/components/ui/AccessibleControls";
import { AccessibleInput } from "@/components/ui/AccessibleControls";

import { useState } from "react";
import { useDropzone } from "react-dropzone";
// @ts-ignore
import imageCompression from "browser-image-compression";
import { saveFile as download } from "@/lib/file-export";
import {
  FileUp,
  Trash2,
  Image as ImageIcon,
  Loader2,
  Download,
  Sliders,
} from "lucide-react";
import { motion } from "framer-motion";

import { useThemeColors } from "@/hooks/useThemeColors";
import {
  useImageCompressorContent,
  type ImageCompressorToolContent,
} from "./image-compressor.content"; //  مسیر نسبی اصلاح شد

export default function ImageCompressorTool() {
  const theme = useThemeColors();
  const content: ImageCompressorToolContent = useImageCompressorContent();

  const [file, setFile] = useState<File | null>(null);
  const [compressedFile, setCompressedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [quality, setQuality] = useState(0.8);

  // URL state
  const [imageUrlInput, setImageUrlInput] = useState("");
  const [isAddingFromUrl, setIsAddingFromUrl] = useState(false);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: { "image/*": [".png", ".jpg", ".jpeg", ".webp"] },
    maxFiles: 1,
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setFile(acceptedFiles[0]);
        setCompressedFile(null);
        setImageUrlInput("");
      }
    },
  });

  const handleCompress = async () => {
    if (!file) return;
    setIsProcessing(true);
    try {
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1920,
        useWebWorker: true,
        initialQuality: quality,
      };
      const compressedBlob = await imageCompression(file, options);
      setCompressedFile(compressedBlob as File);
    } catch (error) {
      alert(content.ui.alerts.error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (compressedFile && file) {
      download(compressedFile, outputFilename(`min-${file.name}`), compressedFile.type);
    }
  };

  // لود تصویر از URL (دانلود با اینترنت خود کاربر، پردازش فقط در مرورگر)
  const handleAddFromUrl = async () => {
    const url = imageUrlInput.trim();
    if (!url) return;

    setIsAddingFromUrl(true);
    try {
      const res = await fetch(url, { mode: "cors" });
      if (!res.ok) {
        throw new Error("Failed to fetch image");
      }

      const blob = await res.blob();
      if (!blob.type.startsWith("image/")) {
        throw new Error("Not an image");
      }

      const urlParts = url.split("/");
      const lastPart = urlParts[urlParts.length - 1] || "image-from-url";
      const cleanName = lastPart.split("?")[0] || "image-from-url";

      const fetchedFile = new File([blob], cleanName, {
        type: blob.type || "image/*",
      });

      setFile(fetchedFile);
      setCompressedFile(null);
      setImageUrlInput("");
    } catch (err) {
      // اگر خواستی جداش کنی، می‌تونی ui.alerts.urlError هم تعریف کنی
      alert(content.ui.alerts.error);
      console.error(err);
    } finally {
      setIsAddingFromUrl(false);
    }
  };

  const originalSizeKB = file && (file.size / 1024).toFixed(1);
  const compressedSizeKB =
    compressedFile && (compressedFile.size / 1024).toFixed(1);
  const reductionPercent =
    file && compressedFile
      ? Math.round((1 - compressedFile.size / file.size) * 100)
      : null;

  return (
    <div
      className={`rounded-3xl border p-6 md:p-10 shadow-xl transition-colors duration-300 ${theme.card} ${theme.border}`}
    >
      {!file ? (
        <AccessibleDropzone
          {...getRootProps()}
          className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-200
          ${
            isDragActive
              ? "border-[var(--app-accent)] scale-[0.99]"
              : `${theme.border} hover:border-[var(--app-accent)]`
          }
          ${theme.bg}
          `}
        >
          <AccessibleInput {...getInputProps()} />
          <div className="flex flex-col items-center gap-4">
            <div className={`p-4 rounded-full ${theme.secondary}`}>
              <FileUp size={32} className={theme.accent} />
            </div>
            <p className={`text-lg font-bold ${theme.text}`}>
              {content.ui.upload.dropTitle}
            </p>
            {content.ui.upload.dropSubtitle && (
              <p className={`text-sm ${theme.textMuted}`}>
                {content.ui.upload.dropSubtitle}
              </p>
            )}
          </div>
        </AccessibleDropzone>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-8"
        >
          <div
            className={`flex items-center justify-between p-4 rounded-xl border ${theme.border} ${theme.bg}`}
          >
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-lg ${theme.secondary}`}>
                <ImageIcon size={24} className={theme.accent} />
              </div>
              <div>
                <p className={`font-bold ${theme.text}`}>{file.name}</p>
                <div className="flex gap-3 text-xs mt-1">
                  {originalSizeKB && (
                    <span className={theme.textMuted}>
                      {content.ui.fileInfo.original} {originalSizeKB} KB
                    </span>
                  )}
                  {compressedSizeKB && reductionPercent !== null && (
                    <span className="text-[var(--app-success-text)] font-bold">
                      {content.ui.fileInfo.compressed} {compressedSizeKB} KB (
                      {reductionPercent}
                      {content.ui.fileInfo.reductionSuffix})
                    </span>
                  )}
                </div>
              </div>
            </div>
            <AccessibleButton purpose="delete"
              onClick={() => {
                setFile(null);
                setCompressedFile(null);
              }}
              className="p-2 text-[var(--app-error-text)] hover:bg-[var(--app-error-bg)] rounded-lg"
            >
              <Trash2 size={20} />
            </AccessibleButton>
          </div>

          <div className={`p-6 rounded-2xl border ${theme.border} ${theme.bg}`}>
            <div className="flex items-center gap-2 mb-4 font-bold">
              <Sliders size={18} /> {content.ui.settings.title}
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{content.ui.settings.qualityLabel}</span>
                <span>{Math.round(quality * 100)}%</span>
              </div>
              <AccessibleInput
                type="range"
                min="0.1"
                max="1"
                step="0.1"
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full h-2 bg-zinc-200 rounded-lg accent-[var(--app-accent)] cursor-pointer"
              />
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={handleCompress}
              disabled={isProcessing}
              className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-lg active:scale-[0.98] ${theme.secondary}`}
            >
              {isProcessing ? (
                <Loader2 className="animate-spin" />
              ) : (
                content.ui.buttons.start
              )}
            </button>

            <button data-testid="download-result"
              onClick={handleDownload}
              disabled={!compressedFile}
              className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-lg active:scale-[0.98] 
              ${
                !compressedFile
                  ? "opacity-50 cursor-not-allowed bg-gray-200 text-gray-500"
                  : theme.primary
              }`}
            >
              <Download /> {content.ui.buttons.download}
            </button>
          </div>
        </motion.div>
      )}

      {/* لود از URL */}
      <div className="mt-6 space-y-2">
        <p className={`text-xs ${theme.textMuted}`}>
          {content.ui.upload.urlHint}
        </p>
        <div className="flex flex-col sm:flex-row gap-2">
          <AccessibleInput
            type="url"
            value={imageUrlInput}
            onChange={(e) => setImageUrlInput(e.target.value)}
            placeholder={content.ui.upload.urlPlaceholder}
            className={`flex-1 px-3 py-2 rounded-xl text-xs border ${theme.border} ${theme.bg} ${theme.text} focus:outline-none focus:ring-1 focus:ring-[var(--app-accent)]`}
          />
          <button
            type="button"
            onClick={handleAddFromUrl}
            disabled={isAddingFromUrl}
            className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-800 text-slate-100 hover:bg-slate-700 disabled:opacity-60"
          >
            {isAddingFromUrl
              ? content.ui.upload.urlLoading
              : content.ui.upload.urlButton}
          </button>
        </div>
      </div>
    </div>
  );
}
