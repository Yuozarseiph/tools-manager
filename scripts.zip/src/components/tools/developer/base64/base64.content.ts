// app/tools/(developer)/base64/base64.content.ts

import { useLanguage } from "@/context/LanguageContext";

export const base64ToolContent = {
  fa: {
    id: "base64",
    category: "developer",
    title: "تبدیل متن و Base64",
    description:
      "متن فارسی و انگلیسی را به Base64 تبدیل کنید یا برعکس، با پشتیبانی کامل از UTF-8.",
    features: [
      "تبدیل متن معمولی به Base64",
      "تبدیل Base64 به متن قابل خواندن",
      "پشتیبانی از کاراکترهای فارسی و یونیکد",
      "کپی سریع خروجی با یک کلیک",
    ],
    ui: {
      input: {
        labelPlain: "متن معمولی",
        labelBase64: "رشته Base64",
        badge: "ورودی",
        placeholderPlain:
          "متن خود را اینجا بنویسید تا به Base64 تبدیل شود...",
        placeholderBase64:
          "رشته Base64 را اینجا قرار دهید تا به متن معمولی تبدیل شود...",
      },
      output: {
        labelPlain: "خروجی متن",
        labelBase64: "خروجی Base64",
        badge: "خروجی",
        placeholder: "نتیجه تبدیل اینجا نمایش داده می‌شود.",
      },
      buttons: {
        swapTitle: "جابجایی ورودی و خروجی",
        copy: "کپی خروجی",
        copied: "کپی شد!",
      },
      errors: {
        invalid: "رشته Base64 نامعتبر است.",
      },
    },
  },
  en: {
    id: "base64",
    category: "developer",
    title: "Text  /  Base64 converter",
    description:
      "Convert plain text to Base64 and back with full UTF-8 support.",
    features: [
      "Convert plain text to Base64",
      "Decode Base64 back to readable text",
      "Supports Unicode and non‑ASCII characters",
      "Quickly copy the result with one click",
    ],
    ui: {
      input: {
        labelPlain: "Plain text",
        labelBase64: "Base64 string",
        badge: "Input",
        placeholderPlain: "Type your text here to encode it as Base64...",
        placeholderBase64: "Paste your Base64 string here to decode it...",
      },
      output: {
        labelPlain: "Plain output",
        labelBase64: "Base64 output",
        badge: "Output",
        placeholder: "The converted result will appear here.",
      },
      buttons: {
        swapTitle: "Swap input and output",
        copy: "Copy output",
        copied: "Copied!",
      },
      errors: {
        invalid: "Invalid Base64 string.",
      },
    },
  },
};

export type Base64ToolContent = typeof base64ToolContent.fa;

export function useBase64Content() {
  const { locale } = useLanguage();
  return base64ToolContent[locale];
}
